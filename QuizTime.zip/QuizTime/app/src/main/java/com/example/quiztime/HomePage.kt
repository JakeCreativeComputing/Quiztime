package com.example.quiztime

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import com.example.quiztime.databinding.ActivityHomePageBinding



class HomePage : AppCompatActivity() {

    private lateinit var binding: ActivityHomePageBinding

            override fun onCreate(savedInstanceState: Bundle?) {
                super.onCreate(savedInstanceState)
                binding = ActivityHomePageBinding.inflate(layoutInflater)
                setContentView(binding.root)

                binding.startbutton.setOnClickListener{
                    startQuiz()
                }

                binding.helpbutton.setOnClickListener{
                    Instructions()
                }

    }

    private fun startQuiz() {
        val start = Intent(this, MainActivity::class.java)
        startActivity(start)
    }


    private fun Instructions() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Quiz Instructions")
        builder.setMessage("1. Read each question carefully.\n" +
                "2. Select the correct answer from the options.\n" +
                "3. You can change your answer before submitting.\n" +
                "4. Click on 'Submit' to finalize your answers.\n" +
                "5. Your score will be displayed at the end of the quiz.\n" +
                "6. Enjoy the Quiz.")

        builder.setPositiveButton("OK") { dialog, _ ->
            dialog.dismiss()
        }

        val dialog: AlertDialog = builder.create()
        dialog.show()
    }
}
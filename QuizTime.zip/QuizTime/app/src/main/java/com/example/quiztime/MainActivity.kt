package com.example.quiztime

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog

import com.example.quiztime.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val questions = arrayOf(
        "What is the main objective in a standard game of Valorant?",
        "Which agent has the ability to heal teammates?",
        "What is the name of the currency used to buy weapons and abilities in Valorant?",
        "Which of the following is NOT a map in Valorant?",
        "Which agent has the ultimate ability called 'Showstopper'?",
        "How many rounds are played in a standard competitive match of Valorant?",
        "What is the maximum number of players in a single Valorant match?",
        "Which weapon is the most expensive in Valorant?",
        "What is the term used for the first round in each half of a Valorant match?",
        "Which agent's abilities are primarily based around poison and toxins?")

    private val options = arrayOf(
        arrayOf("Capture the Flag", "Domination", "Planting/Defusing the Spike", "Team Deathmatch"),
        arrayOf("Jett", "Sage", "Phoenix", "Brimstone"),
        arrayOf("Credits", "Gold", "Valor Coins", "Riot Points"),
        arrayOf("Bind", "Split", "Haven", "Dust II"),
        arrayOf("Raze", "Viper", "Reyna", "Omen"),
        arrayOf("20", "24", "25", "30"),
        arrayOf("5", "10", "15", "20"),
        arrayOf("Phantom", "Vandal", "Operator", "Guardian"),
        arrayOf("Buy Round", "Bonus Round", "Pistol Round", "Eco Round"),
        arrayOf("Cypher", "Viper", "Breach", "Skye")
    )

    private val correctAnswers = arrayOf(
        2,  // "Planting/Defusing the Spike"
        1,  // "Sage"
        0,  // "Credits"
        3,  // "Dust II"
        0,  // "Raze"
        3,  // "30"
        1,  // "10"
        2,  // "Operator"
        2,  // "Pistol Round"
        1   // "Viper"
    )

    private var currentQuestionIndex = 0

    private var score = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        displayQuestion()

        binding.lastResultsButton.setOnClickListener(){
            lastscore()
        }

        binding.option1button.setOnClickListener{
            checkAnswer(0)
        }

        binding.option2button.setOnClickListener{
            checkAnswer(1)
        }

        binding.option3button.setOnClickListener{
            checkAnswer(2)
        }

        binding.option4button.setOnClickListener{
            checkAnswer(3)
        }

        binding.restartbutton.setOnClickListener{
            restartQuiz()
        }

    }

    private fun correctButtonColors(buttonIndex: Int){
        when(buttonIndex){
            0 -> binding.option1button.setBackgroundColor(Color.GREEN)
            1 -> binding.option2button.setBackgroundColor(Color.GREEN)
            2 -> binding.option3button.setBackgroundColor(Color.GREEN)
            3 -> binding.option4button.setBackgroundColor(Color.GREEN)
        }
    }

    private fun wrongButtonColor(buttonIndex: Int){
        when(buttonIndex){
            0 -> binding.option1button.setBackgroundColor(Color.RED)
            1 -> binding.option2button.setBackgroundColor(Color.RED)
            2 -> binding.option3button.setBackgroundColor(Color.RED)
            3 -> binding.option4button.setBackgroundColor(Color.RED)
        }
    }

    private fun resetButtonColors(){
        binding.option1button.setBackgroundColor(Color.rgb(51,92,103))
        binding.option2button.setBackgroundColor(Color.rgb(51,92,103))
        binding.option3button.setBackgroundColor(Color.rgb(51,92,103))
        binding.option4button.setBackgroundColor(Color.rgb(51,92,103))
    }

    private fun showResults() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Quiz Results")
        builder.setMessage("Your score: $score out of ${questions.size}")

        builder.setPositiveButton("OK") { dialog, _ ->
            dialog.dismiss()

        }
        binding.restartbutton.isEnabled = true
        val dialog: AlertDialog = builder.create()
        dialog.show()
    }



    private fun displayQuestion(){
        binding.questionText.text = questions[currentQuestionIndex]
        binding.option1button.text = options[currentQuestionIndex][0]
        binding.option2button.text = options[currentQuestionIndex][1]
        binding.option3button.text = options[currentQuestionIndex][2]
        binding.option4button.text = options[currentQuestionIndex][3]
        resetButtonColors()
    }

    private fun checkAnswer(selectedAnswerIndex: Int){
        val correctAnswerIndex = correctAnswers[currentQuestionIndex]

        if(selectedAnswerIndex == correctAnswerIndex){
            score++
            correctButtonColors(selectedAnswerIndex)
        }
        else{
            wrongButtonColor(selectedAnswerIndex)
            correctButtonColors(correctAnswerIndex)
        }

        if (currentQuestionIndex < questions.size - 1) {
            currentQuestionIndex++
            binding.questionText.postDelayed({displayQuestion()},1000)

        }
        else{
            showResults()
        }
    }

    private fun restartQuiz(){
        currentQuestionIndex = 0
        score = 0
        displayQuestion()
        binding.restartbutton.isEnabled = false
    }

    private fun lastscore() {
        Toast.makeText(this,"Most Recent Score : $score out of ${questions.size}", Toast.LENGTH_LONG).show()
    }




}